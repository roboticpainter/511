#include "Report.h"

// constructor to create a report

// write a display function
